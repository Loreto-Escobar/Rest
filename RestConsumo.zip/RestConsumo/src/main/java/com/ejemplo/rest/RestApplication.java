package com.ejemplo.rest;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ejemplo.rest.modelo.Post;
import com.ejemplo.rest.servicio.IServicioPost;

@SpringBootApplication
public class RestApplication {

	public static void main(String[] args) {
		//SpringApplication.run(RestApplication0new.class, args);
		AnnotationConfigApplicationContext acac= new AnnotationConfigApplicationContext(RestApplication.class);
		IServicioPost servicio=acac.getBean(IServicioPost.class);
		List<Post> posteos=servicio.buscarPostsPorUsuario(10);
		for(Post posteo:posteos) {
		System.out.println(posteo.getId());
		
	 }
	}
}
