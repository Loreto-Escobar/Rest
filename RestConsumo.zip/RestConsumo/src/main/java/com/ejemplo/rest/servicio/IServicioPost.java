package com.ejemplo.rest.servicio;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ejemplo.rest.modelo.Post;

@Service
public interface IServicioPost{
	
	public Post buscarPost(Integer id);
	
	public List<Post> buscarPosts();
	
	
	public List<Post> buscarPostsPorUsuario(Integer idUsuario);	
	
}
