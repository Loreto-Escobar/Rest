package com.ejemplo.rest.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ejemplo.rest.modelo.Post;
@Service
public class  ServicioPost implements IServicioPost{

	@Autowired
	RestTemplate restTemplate;
	
	
	@Override
	public Post buscarPost(Integer id) {
				
			ResponseEntity<Post> response=restTemplate.exchange("https://jsonplaceholder.typicode.com/posts/1",
											 HttpMethod.GET
											 ,null
											 ,Post.class);
			return response.getBody();
		}


	@Override
	public List<Post> buscarPosts() {
		// TODO Auto-generated method stub
		return restTemplate.exchange("https://jsonplaceholder.typicode.com/posts" 
									  ,HttpMethod.GET
									  , null
									  , new ParameterizedTypeReference<List<Post>>(){
									}).getBody();
	}


	@Override
	public List<Post> buscarPostsPorUsuario(Integer idUsuario) {
		
		String url=String.format("https://jsonplaceholder.typicode.com/posts?userId=%d", idUsuario);
		
		return restTemplate.exchange( url
				  ,HttpMethod.GET
				  , null
				  , new ParameterizedTypeReference<List<Post>>(){
				}).getBody();
	}
	
	
}
